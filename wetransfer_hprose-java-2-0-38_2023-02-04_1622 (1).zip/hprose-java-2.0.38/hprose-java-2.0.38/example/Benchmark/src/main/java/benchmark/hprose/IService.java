package benchmark.hprose;

public interface IService  {
    String hello(String name);
}
