package hprose.example.io;

public class User {
    public String name;
    public int age;
}
