package hprose.example.tcp;

public class User {
    public String name;
    public int age;
}
