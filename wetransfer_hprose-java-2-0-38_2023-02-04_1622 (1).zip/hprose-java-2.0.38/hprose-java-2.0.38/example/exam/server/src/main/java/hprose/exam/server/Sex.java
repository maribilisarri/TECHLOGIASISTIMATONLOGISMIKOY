package hprose.exam.server;

public enum Sex {
    Unknown, Male, Female, InterSex
}